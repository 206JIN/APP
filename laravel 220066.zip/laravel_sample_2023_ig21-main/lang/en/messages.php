<?php

return [
    'item_name' => 'Item name',
    'price' => 'Price',
    'update' => 'Update',
    'back' => 'Back',
    'delete' => 'Delete',
];
