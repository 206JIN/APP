<?php

return [
    'item_name' => '商品名',
    'price' => '価格',
    'update' => '更新',
    'back' => '戻る',
    'delete' => '削除',
];
